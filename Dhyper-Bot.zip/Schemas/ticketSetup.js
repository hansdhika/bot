import mongoose from 'mongoose';

const ticketSetup = new mongoose.Schema({  
    GuildID: String,
    Channel: String,
    Category: String,
    Transcripts: String,
    Handlers: String,
    Everyone: String,
    Description: String,
    Button: String,
    Emoji: String,});

export default ticketSetup;