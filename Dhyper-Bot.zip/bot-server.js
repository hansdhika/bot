/*
From https://u.com/@BeauCarnes/Encourage-Bot-JS#server.js

This file is an option to keep your discord bot online even when the tab is offline.

Two options for keeping your bot online are:

1. Upgrade your repl.it to set your project to "always on"

2. Use Uptime Robot (run keepAlive(), copy the link generated from the window, then paste it into a new Uptime Robot monitor)
*/

// Require the express library
import express from 'express';
import mongoose from 'mongoose';


// Create a server with express
const server = express();
const mongodburl = process.env['mongodburl'];
mongoose.connect(mongodburl,
);
const db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error: "));
db.once("open", function () {
  console.log("Connected successfully");
});
// Responds to all HTTP requests
server.all("/", (req, res) => {
  res.send("Bot is running!");
})

// Keeps repl.it instance alive
function keepAlive() {
  server.listen(3000, () => {
    console.log("Server is ready.");
  })
}

//export to be used in index.js
export default keepAlive;