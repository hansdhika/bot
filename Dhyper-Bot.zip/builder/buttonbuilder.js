import {ActionRowBuilder, ButtonStyle , ButtonBuilder} from 'discord.js'
// Button ML Produk
export const mlabutton = new ButtonBuilder().setCustomId('mla').setLabel('DM ML A').setStyle(ButtonStyle.Primary);

export const weeklymlbutton = new ButtonBuilder().setCustomId('weeklyml').setLabel('Weekly Pass').setStyle(ButtonStyle.Primary);

// Button Payment List
export const banktransfer = new ButtonBuilder().setCustomId('bank').setLabel('Bank Transfer').setStyle(ButtonStyle.Primary);

export const ewallet = new ButtonBuilder().setCustomId('ewallet').setLabel('E-Wallet').setStyle(ButtonStyle.Primary);

export const bcabutton = new ButtonBuilder().setCustomId('bca').setEmoji({name:'bca',id:'1133068603705532537'}).setLabel('Bank BCA').setStyle(ButtonStyle.Secondary);

export const bributton = new ButtonBuilder().setCustomId('bri').setEmoji({name:'bri',id:'1133070236283830273'}).setLabel('Bank BRI').setStyle(ButtonStyle.Secondary);

export const seabankbutton = new ButtonBuilder().setCustomId('seabank').setEmoji({name:'seabank',id:'1133070411404423220'}).setLabel('SeaBank').setStyle(ButtonStyle.Secondary);

export const blubutton = new ButtonBuilder().setCustomId('blu').setEmoji({name:'blu',id:'1133070271876694057'}).setLabel('Blu BCA Digital').setStyle(ButtonStyle.Secondary);

// Button Contact Person
export const facebook = new ButtonBuilder().setEmoji({name:'facebook',id:'1144888801748070461'}).setLabel('Facebook').setURL('https://m.facebook.com/hansdhik').setStyle(ButtonStyle.Link);

export const wabiasa = new ButtonBuilder().setEmoji({name:'whatsapp',id:'1144885928909865070'}).setLabel('WhatsApp').setURL('https://wa.me/message/KYJURT7XXW2HI1').setStyle(ButtonStyle.Link);

export const discord = new ButtonBuilder().setEmoji({name:'discord',id:'1144888746819461120'}).setLabel('Server Discord').setURL('https://discord.gg/kv7wtCfkVq').setStyle(ButtonStyle.Link);

export const instagram = new ButtonBuilder().setEmoji({name:'ig',id:'1144885877756153876'}).setLabel('Instagram').setURL('https://instagram.com/hansdhika').setStyle(ButtonStyle.Link);

export const youtube = new ButtonBuilder().setEmoji({name:'youtube',id:'1144885821846077440'}).setLabel('Youtube').setURL('https://www.youtube.com/@hansdhika').setStyle(ButtonStyle.Link);

// Button Akun Owner
export const akunsage = new ButtonBuilder().setCustomId('ownersageakun').setLabel('Ninja Sage').setStyle(ButtonStyle.Primary);

export const akunsage1 = new ButtonBuilder().setCustomId('sageakun1').setLabel('Lv 20').setStyle(ButtonStyle.Primary);

export const akunsage2 = new ButtonBuilder().setCustomId('sageakun2').setLabel('Lv 40').setStyle(ButtonStyle.Primary);

export const akunsage3 = new ButtonBuilder().setCustomId('sageakun3').setLabel('Lv 60').setStyle(ButtonStyle.Primary);

export const akunsage4 = new ButtonBuilder().setCustomId('sageakun4').setLabel('Lv 75').setStyle(ButtonStyle.Primary);

export const akunml = new ButtonBuilder().setCustomId('ownermlakun').setLabel('mlbbakun').setStyle(ButtonStyle.Primary);

export const cekml = new ButtonBuilder().setCustomId('cekml').setLabel('Cek').setStyle(ButtonStyle.Primary);


// Button Produk List
export const tumobile = new ButtonBuilder().setCustomId('topupmobile').setLabel('Top Up Mobile').setStyle(ButtonStyle.Primary);

export const tupc = new ButtonBuilder().setCustomId('topuppc').setLabel('Top Up PC').setStyle(ButtonStyle.Primary);

export const tujoki = new ButtonBuilder().setCustomId('topupjoki').setLabel('Joki').setStyle(ButtonStyle.Primary);

export const tudaily = new ButtonBuilder().setCustomId('topupdaily').setLabel('Top Up Daily').setStyle(ButtonStyle.Primary);

// Button Undawn Produk
export const undawntopup1 = new ButtonBuilder().setCustomId('undawntu1').setLabel('RC').setStyle(ButtonStyle.Primary);

export const undawntopup2 = new ButtonBuilder().setCustomId('undawntu2').setLabel('Supply Card').setStyle(ButtonStyle.Primary);

export const undawntopup3 = new ButtonBuilder().setCustomId('undawntu3').setLabel('Growth Fund').setStyle(ButtonStyle.Primary);

export const undawntopup4 = new ButtonBuilder().setCustomId('undawntu4').setLabel('Glory Pass Premium').setStyle(ButtonStyle.Primary);

// Button Ninja Sage Produk
export const sagejoki1 = new ButtonBuilder().setCustomId('sagejoki1').setLabel('Pilot Daily').setStyle(ButtonStyle.Primary);

export const sagejoki2 = new ButtonBuilder().setCustomId('sagejoki2').setLabel('Event Summer').setStyle(ButtonStyle.Primary);

export const sagejoki3 = new ButtonBuilder().setCustomId('sagejoki3').setLabel('Event Garuda').setStyle(ButtonStyle.Primary);

// Button Free Fire
export const ff1 = new ButtonBuilder().setCustomId('ff1').setLabel('DM FF').setStyle(ButtonStyle.Primary);

export const ff2 = new ButtonBuilder().setCustomId('ff2').setLabel('Membership').setStyle(ButtonStyle.Primary);

export const ff3 = new ButtonBuilder().setCustomId('ff3').setLabel('Battle Pass').setStyle(ButtonStyle.Primary);

// Button Metal Slug
export const msl1 = new ButtonBuilder().setCustomId('msl1').setLabel('Ruby').setStyle(ButtonStyle.Primary);

export const msl2 = new ButtonBuilder().setCustomId('msl2').setLabel('Monthly Card').setStyle(ButtonStyle.Primary);

//button token pln
export const tokenpln1 = new ButtonBuilder().setCustomId('tokenpln1').setLabel('Token PLN').setStyle(ButtonStyle.Primary);

export const rowmslugproduk = new ActionRowBuilder().addComponents(msl1,msl2);

export const rowffproduk = new ActionRowBuilder().addComponents(ff1,ff2,ff3);

export const rownsageproduk = new ActionRowBuilder().addComponents(sagejoki1,sagejoki2,sagejoki3);

export const rowundawn = new ActionRowBuilder().addComponents(undawntopup1,undawntopup2,undawntopup3,undawntopup4);

export const rowproduk = new ActionRowBuilder().addComponents(tumobile,tupc,tujoki,tudaily);

export const rowakungame = new ActionRowBuilder().addComponents(akunml,akunsage);

export const rowsosmed = new ActionRowBuilder().addComponents(facebook,discord,wabiasa,youtube,instagram);

export const rowbank = new ActionRowBuilder().addComponents(bcabutton , bributton , blubutton , seabankbutton);

export const rowpayment = new ActionRowBuilder().addComponents(banktransfer,ewallet);

export const rowmlproduk = new ActionRowBuilder().addComponents(mlabutton , weeklymlbutton);

export const rowakunsage = new ActionRowBuilder().addComponents(akunsage1 , akunsage2 , akunsage3 , akunsage4);