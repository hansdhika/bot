import { EmbedBuilder } from 'discord.js';

export const halo = new EmbedBuilder()
  .setTitle("Selamat Datang di Undergaming World")
  .setDescription("Discord group since : 24.07.2023\n\nAmbil Role buat buka fitur chat\n<#1133075157913710653>\nInformasi Produk\n<#1143958165407404203>\nInformasi Kontak\n<#1115399580557787136>\nInformasi Pembayaran\n<#1115414609566896260>\nMabar? Langsung add\n<#1144893138952007803>\n\nBuat yang mau ngasih saran , entah request channel , konten, dll \n<#1144796794623098992>")
  .setColor(0xff0000).setThumbnail("https://i.imgur.com/3kHOntc.jpg")
  .setFooter({
    text: "\u00A9\ Undergaming World 2023."
  });

export const welcomenewmem = new EmbedBuilder().setTitle('Selamat datang, ');

export const contactperson = new EmbedBuilder().setTitle('Informasi Kontak Owner').setThumbnail('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQOShLA49QoQrrs0jGOFtXlxFLYLsLAXJ1Uvw&usqp=CAU').setColor(0x858585).setDescription('Sosial Media Admin:\n<:facebook:1144888801748070461>\t**Facebook**\n<:discord:1144888746819461120>\t**Server Discord**\n<:whatsapp:1144885928909865070>\t**WhatsApp**\n<:youtube:1144885821846077440>\t**Youtube**\n<:ig:1144885877756153876>\t**Instagram**');

export const gameakun = new EmbedBuilder().setTitle('List Akun Game').setDescription('Kali - kali pengen mabar have fun / Buat recruit').setThumbnail('https://cdn-icons-png.flaticon.com/512/2780/2780137.png');

export const akunsagebuilder = new EmbedBuilder().setTitle('Akun Sage').setDescription('Yang mau add akun aing buat recruitan silahkan pilih berdasarkan level').setThumbnail('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSczG3LXkM-iE-eX0UzK4_Ue-U22DY2EEG3ug&usqp=CAU');

export const akunmlbuilder = new EmbedBuilder().setTitle('Akun ML').setDescription('Sorry gabisa gendong wkwk tapi yang mau mabar monggo :v').setThumbnail('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3aQzPBQWcXr_XJlyvoTNRZPOa_HSNTwz_fA&usqp=CAU');

export const akunmetalslugbuilder = new EmbedBuilder().setTitle('Akun Metal Slug').setDescription('Belum Main Gaes :v').setThumbnail('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSw3RntEyE42j7dJPMk1O6fHh1r4fiOnOlqIw&usqp=CAU');

export const produk = new EmbedBuilder().setTitle('List Produk').setDescription('Pilih produk sesuai kebutuhan')
  .setColor(0xffffff).setThumbnail("https://i.imgur.com/3kHOntc.jpg")
  .setFooter({
    text: "\u00A9\ Undergaming World 2023."
  });

export const ffproduk = new EmbedBuilder().setTitle('List Harga Free Fire').setDescription('Pilih salah satu produk dibawah ini untuk melihat harga\n\n\nBack to <#1143958165407404203>').setThumbnail('https://www.bhmpics.com/downloads/mobile-legends-logo/46.mlbb-1.png').setTimestamp().setFooter({ text: 'Updated' });

export const pubgmproduk = new EmbedBuilder().setTitle('List Harga PUBGM').setDescription('Pilih salah satu produk dibawah ini untuk melihat harga\n\n\nBack to <#1143958165407404203>').setThumbnail('https://www.bhmpics.com/downloads/mobile-legends-logo/46.mlbb-1.png').setTimestamp().setFooter({ text: 'Updated' });

export const mslgproduk = new EmbedBuilder().setTitle('List Harga Metal Slug').setDescription('Pilih salah satu produk dibawah ini untuk melihat harga\n\n\nBack to <#1143958165407404203>').setThumbnail('https://www.bhmpics.com/downloads/mobile-legends-logo/46.mlbb-1.png').setTimestamp().setFooter({ text: 'Updated' });

export const plnproduk = new EmbedBuilder().setTitle('List Harga Token PLN').setDescription('Pilih salah satu produk dibawah ini untuk melihat harga\n\n\nBack to <#1143958165407404203>').setThumbnail('https://www.bhmpics.com/downloads/mobile-legends-logo/46.mlbb-1.png').setTimestamp().setFooter({ text: 'Updated' });

export const ewalletproduk = new EmbedBuilder().setTitle('List Harga E-Wallet').setDescription('Pilih salah satu produk dibawah ini untuk melihat harga\n\n\nBack to <#1143958165407404203>').setThumbnail('https://www.bhmpics.com/downloads/mobile-legends-logo/46.mlbb-1.png').setTimestamp().setFooter({ text: 'Updated' });

export const internetproduk = new EmbedBuilder().setTitle('List Harga Paket Internet').setDescription('Pilih salah satu produk dibawah ini untuk melihat harga\n\n\nBack to <#1143958165407404203>').setThumbnail('https://www.bhmpics.com/downloads/mobile-legends-logo/46.mlbb-1.png').setTimestamp().setFooter({ text: 'Updated' });

export const pulsaproduk = new EmbedBuilder().setTitle('List Harga Pulsa').setDescription('Pilih salah satu produk dibawah ini untuk melihat harga\n\n\nBack to <#1143958165407404203>').setThumbnail('https://www.bhmpics.com/downloads/mobile-legends-logo/46.mlbb-1.png').setTimestamp().setFooter({ text: 'Updated' });

export const gpcproduk = new EmbedBuilder().setTitle('List Harga Google Play Credit (IDR)').setDescription('Pilih salah satu produk dibawah ini untuk melihat harga\n\n\nBack to <#1143958165407404203>').setThumbnail('https://www.bhmpics.com/downloads/mobile-legends-logo/46.mlbb-1.png').setTimestamp().setFooter({ text: 'Updated' });

export const valoproduk = new EmbedBuilder().setTitle('List Harga Valorant Point').setDescription('Pilih salah satu produk dibawah ini untuk melihat harga\n\n\nBack to <#1143958165407404203>').setThumbnail('https://www.bhmpics.com/downloads/mobile-legends-logo/46.mlbb-1.png').setTimestamp().setFooter({ text: 'Updated' });

export const pbcashproduk = new EmbedBuilder().setTitle('List Harga Point Blank Cash').setDescription('Pilih salah satu produk dibawah ini untuk melihat harga\n\n\nBack to <#1143958165407404203>').setThumbnail('https://www.bhmpics.com/downloads/mobile-legends-logo/46.mlbb-1.png').setTimestamp().setFooter({ text: 'Updated' });

export const litaproduk = new EmbedBuilder().setTitle('List Harga Lita Coin').setDescription('Pilih salah satu produk dibawah ini untuk melihat harga\n\n\nBack to <#1143958165407404203>').setThumbnail('https://www.bhmpics.com/downloads/mobile-legends-logo/46.mlbb-1.png').setTimestamp().setFooter({ text: 'Updated' });

export const gsproduk = new EmbedBuilder().setTitle('List Harga Garena Shell').setDescription('Pilih salah satu produk dibawah ini untuk melihat harga\n\n\nBack to <#1143958165407404203>').setThumbnail('https://www.bhmpics.com/downloads/mobile-legends-logo/46.mlbb-1.png').setTimestamp().setFooter({ text: 'Updated' });

export const banktrans = new EmbedBuilder().setTitle('Bank Transfer').setThumbnail('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTzA4OTCwcuxomfmLlVKVCt0oXw33-9DwUlLw&usqp=CAU').setDescription('Silahkan Pilih Bank yang ingin di transfer').setColor(0x4287f5);

export const undawn = new EmbedBuilder().setTitle('Undawn');

export const metalslug = new EmbedBuilder().setTitle('Metal Slug');

export const paymentlist = new EmbedBuilder()
  .setTitle("Payment List")
  .setDescription("**Bank List**\n\n<:bca:1133068603705532537>\t**BCA**\t:\t0870134924\n<:bri:1133070236283830273>\t**BRI**\t:\t709301005619531\n<:blu:1133070271876694057>\t**Blu BCA digital**\t:\t003812565347\n<:seabank:1133070411404423220>\t**Seabank**\t:\t901038789954\n<:an:1144805997114835015>\t**An**\tHans Dhika Permana\n\n**Ewallet List**\n\n<:dana:1133070302608380034>\t**Dana**\t:\t082237455940\n<:spay:1133070383763968150>\t**ShopeePay**\t:\t082237455940")
  .setColor(0xff0000).setThumbnail("https://i.imgur.com/3kHOntc.jpg")
  .setFooter({
    text: "Klik tombol dibawah agar mudah di copy paste"
  });

export const embedjoki = new EmbedBuilder().setTitle('Joki Area').setDescription('For check\n\n<:rightarrow:1144979799782203412>\t**Ninja Sage**\nCek konten<#1115419759639531630>\nOrder<#1144965818443120680>\n\n<:rightarrow:1144979799782203412>\t**Undawn**\nCek konten<#1135961175922847814>\nOrder<#1144966128964223078>').setThumbnail('https://cdn-icons-png.flaticon.com/128/1982/1982124.png');

export const embedtopupmobile = new EmbedBuilder().setTitle('Top Up Mobile').setDescription('For check\n\n<:rightarrow:1144979799782203412>\t**Mobile Legends**\nCek konten<#1135961572360065105>\nOrder<#1144965447117189251>').setThumbnail('https://cdn-icons-png.flaticon.com/128/3437/3437364.png');

export const embedtopupdaily = new EmbedBuilder().setTitle('Top Up Daily').setDescription('For check\n\n<:rightarrow:1144979799782203412>\t**Ninja Sage**\nCek konten<#1115419759639531630>\nOrder<#1144965818443120680>').setThumbnail('https://cdn-icons-png.flaticon.com/128/8712/8712925.png');

export const embedtopuppc = new EmbedBuilder().setTitle('Top Up PC').setDescription('For check\n\n<:rightarrow:1144979799782203412>\t**Ninja Sage**\nCek konten<#1115419759639531630>\nOrder<#1144965818443120680>').setThumbnail('https://cdn-icons-png.flaticon.com/128/2317/2317963.png');