import { SlashCommandBuilder } from 'discord.js';

const contactpersonCommand = new SlashCommandBuilder()
  .setName('listcp')
  .setDescription('Informasi Kontak');

export default contactpersonCommand.toJSON();