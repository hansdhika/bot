import { SlashCommandBuilder } from 'discord.js';

const akungameCommand = new SlashCommandBuilder()
  .setName('akungame')
  .setDescription('Daftar Harga ML');

export default akungameCommand.toJSON();