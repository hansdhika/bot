import { SlashCommandBuilder } from 'discord.js';

const haloCommand = new SlashCommandBuilder()
  .setName('halo')
  .setDescription('Welcome');

export default haloCommand.toJSON();