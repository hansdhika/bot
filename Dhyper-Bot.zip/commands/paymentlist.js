import { SlashCommandBuilder } from 'discord.js';

const paymentListCommand = new SlashCommandBuilder()
  .setName('paymentlist')
  .setDescription('Daftar Pembayaran');

export default paymentListCommand.toJSON();