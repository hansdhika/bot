import { SlashCommandBuilder} from 'discord.js';


const priceffCommand = new SlashCommandBuilder()
  .setName('priceff')
  .setDescription('Daftar Harga Free Fire');

export default priceffCommand.toJSON();