import { SlashCommandBuilder} from 'discord.js';


const pricemlCommand = new SlashCommandBuilder()
  .setName('priceml')
  .setDescription('Daftar Harga ML');

export default pricemlCommand.toJSON();