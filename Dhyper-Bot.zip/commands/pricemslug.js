import { SlashCommandBuilder} from 'discord.js';


const pricemetalslugCommand = new SlashCommandBuilder()
  .setName('pricemetalslug')
  .setDescription('Daftar Harga Metal Slug');

export default pricemetalslugCommand.toJSON();