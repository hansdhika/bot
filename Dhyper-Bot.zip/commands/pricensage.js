import { SlashCommandBuilder} from 'discord.js';


const pricensageCommand = new SlashCommandBuilder()
  .setName('pricensage')
  .setDescription('Daftar Harga NSage');


export default pricensageCommand.toJSON();