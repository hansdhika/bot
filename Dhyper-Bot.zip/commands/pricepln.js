import { SlashCommandBuilder} from 'discord.js';


const pricetokenplnCommand = new SlashCommandBuilder()
  .setName('pricetokenpln')
  .setDescription('Daftar Harga Token PLN');

export default pricetokenplnCommand.toJSON();