import { SlashCommandBuilder} from 'discord.js';


const priceundawnCommand = new SlashCommandBuilder()
  .setName('priceundawn')
  .setDescription('Daftar Harga Undawn');

export default priceundawnCommand.toJSON();