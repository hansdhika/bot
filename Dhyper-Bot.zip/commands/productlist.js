import { SlashCommandBuilder} from 'discord.js';


const produkCommand = new SlashCommandBuilder()
  .setName('pr')
  .setDescription('List Produk');

export default produkCommand.toJSON();