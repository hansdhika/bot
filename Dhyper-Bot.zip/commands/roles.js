import { SlashCommandBuilder } from 'discord.js';

export const setrolesCommand = new SlashCommandBuilder()
  .setName('setrole')
  .setDescription('Set Role Member')
  .addUserOption((option) =>
    option
      .setName('user')
      .setDescription('Pilih Member :')
      .setRequired(true))
  .addRoleOption((option) =>
    option.setName('role').setDescription('Pilih Role:').setRequired(true));

export const rerolesCommand = new SlashCommandBuilder().setName('removerole').setDescription('Remove Role Member').addUserOption((option) =>
  option.setName('user').setDescription('Pilih Member:').setRequired(true)).addRoleOption((option) => option.setName('role').setDescription('Pilih Role:').setRequired(true));

export const reactionrolesCommand = new SlashCommandBuilder().setName('reaction-role').setDescription('manage your reaction roles')
  .addSubcommand(command => command.setName('add').setDescription('Add reaction roles')
    .addStringOption(option => option.setName('messages-id').setDescription('the messages id').setRequired(true))
    .addStringOption(option => option.setName('emoji').setDescription('Emoji React').setRequired(true))
     .addRoleOption(option => option.setName('role').setDescription('Roles add').setRequired(true)))
  .addSubcommand(command => command.setName('remove').setDescription('Remove reaction roles')
    .addStringOption(option => option.setName('messages-id').setDescription('the messages id').setRequired(true))
    .addStringOption(option => option.setName('emoji').setDescription('Emoji React').setRequired(true))
    .addRoleOption(option => option.setName('role').setDescription('Select Role').setRequired(true)));