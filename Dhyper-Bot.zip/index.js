import { config } from 'dotenv';
import {
  ActionRowBuilder,
  Client,
  GatewayIntentBits,
  Routes,
  SelectMenuBuilder,
  PermissionsBitField,
  EmbedBuilder,
  REST,
  
} from 'discord.js';

import ms from 'ms';

import OrderCommand from './commands/order.js';
import {setrolesCommand,
       rerolesCommand,
       reactionrolesCommand,
       } from './commands/roles.js';
import UsersCommand from './commands/user.js';
import ChannelsCommand from './commands/channel.js';
import BanCommand from './commands/ban.js';
import RegisterCommand from './commands/register.js';
import haloCommand from './commands/halo.js';
import keepAlive from './bot-server.js';
import pricetokenplnCommand from './commands/pricepln.js';
import pricemlCommand from './commands/priceml.js';
import pricensageCommand from './commands/pricensage.js';
import priceffCommand from './commands/priceff.js';
import priceundawnCommand from './commands/priceundawn.js';
import {
  halo,
  paymentlist,
  banktrans,
  contactperson,
  gameakun,
  akunsagebuilder,
  akunmlbuilder,
  akunmetalslugbuilder,
  produk,
  embedjoki,
  embedtopupmobile,
  embedtopuppc,
  embedtopupdaily,
} from './builder/halobuilder.js';
import paymentListCommand from './commands/paymentlist.js';
import {
  rowmlproduk,
  rowpayment,
  rowbank,
  rowsosmed,
  rowakungame,
  rowproduk,
  rownsageproduk,
  rowffproduk,
  rowundawn,
  rowmslugproduk,
  rowakunsage,
  cekml,
  tokenpln1,
  
  
} from './builder/buttonbuilder.js';
import contactpersonCommand from './commands/contactperson.js';
import akungameCommand from './commands/gameacount.js';
import pricemetalslugCommand from './commands/pricemslug.js';
import produkCommand from './commands/productlist.js';
import {
  mlproduk,
  mla,
  weeklyml,
 } from './produk/mlproduk.js';
import {
  nsageproduk,
  jokisage1,
  jokisage2,
  jokisage3,
} from './produk/nsageproduk.js';
import {
  undawnproduk,
  undawntopup1,
  undawntopup2,
  undawntopup3,
  undawntopup4,
  
} from './produk/undawnproduk.js';

import {
  ffproduk,
  dmff,
  ffpass,
  ffbpcard,
  
} from './produk/ffproduk.js';
import {
  mslugproduk,
  mslug1,
  mslug2,
} from './produk/mslugproduk.js';

import {
  plnproduk,
  tokenpln
} from './produk/plnproduk.js';
import {
  pubgmproduk,
} from './produk/pubgmproduk.js';
import mongoose from 'mongoose';
import giveawayCommand from './giveaway.js';
import {GiveawaysManager} from 'discord-giveaways';
import {
  setTimeout,
} from 'timers/promises';
import giveawaySchema from './Schemas/giveawaySchema.js';

keepAlive();
config();
const TOKEN = process.env['TOKEN'];
const CLIENT_ID = process.env.CLIENT_ID;
const GUILD_ID = process.env.GUILD_ID;
const MANGOODBURL = 
process.env['mongodburl'];

const wait = setTimeout;

const rest = new REST().setToken(TOKEN);

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildPresences
  ],
});
const giveawayModel = mongoose.model('giveaways', giveawaySchema);
const GiveawayManagerWithOwnDatabase = class extends GiveawaysManager {
    // This function is called when the manager needs to get all giveaways which are stored in the database.
    async getAllGiveaways() {
        // Get all giveaways from the database. We fetch all documents by passing an empty condition.
        return await giveawayModel.find().lean().exec();
    }

    // This function is called when a giveaway needs to be saved in the database.
    async saveGiveaway(messageId, giveawayData) {
        // Add the new giveaway to the database
        await giveawayModel.create(giveawayData);
        // Don't forget to return something!
        return true;
    }

    // This function is called when a giveaway needs to be edited in the database.
    async editGiveaway(messageId, giveawayData) {
        // Find by messageId and update it
        await giveawayModel.updateOne({ messageId }, giveawayData).exec();
        // Don't forget to return something!
        return true;
    }

    // This function is called when a giveaway needs to be deleted from the database.
    async deleteGiveaway(messageId) {
        // Find by messageId and delete it
        await giveawayModel.deleteOne({ messageId }).exec();
        // Don't forget to return something!
        return true;
    }
};
const manager = new GiveawayManagerWithOwnDatabase(client, {
    default: {
        botsCanWin: false,
        embedColor: "Random",
        embedColorEnd: '#9fef14',
        reaction: '🎉'

    }
});

client.giveawaysManager = manager;
client.giveawaysManager.on("giveawayEnded", (giveaway, winners) => {
    winners.forEach((member) => {
        member.send(`**Selamat ${member.user.username}, anda memenangkan ${giveaway.prize} !**, pm ${giveaway.hostedBy} untuk claim hadiah`);
    })
});


client.on('ready', () => console.log(`${client.user.tag} has logged in!`));


client.on('interactionCreate', async interaction => {

  //Set Role
if(interaction.commandName === 'setrole'){
    
if(!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await interaction.reply({content : 'you dont have a permissions.' , ephemeral : true,});

const member = interaction.options.getMember('user');
const role = interaction.options.getRole('role');
if (member.roles.cache.has(role.id)){
  return await interaction.reply({content:'Member already that role.',ephemeral:'true'});
}
  else {
member.roles.add(role).catch(console.error);
  }
    await interaction.reply({embeds:[new EmbedBuilder().setDescription(`**${role}** has been added to **${member}**`)]});
  }

//ReadMe
else if(interaction.commandName === 'halo'){
if(!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await interaction.reply({content : 'you dont have a permissions.' , ephemeral : true});

  return await interaction.reply({
    embeds :[halo]
  });
}

//Payment List
else if(interaction.commandName === 'paymentlist'){
  if(!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await interaction.reply({content : 'you dont have a permissions.' , ephemeral : true,});

  return await interaction.reply({
    embeds :[paymentlist],
    contents : [rowpayment]
  });
}
  
// Produk List
else if (interaction.commandName === 'pr'){
      if(!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await interaction.reply({content : 'you dont have a permissions.' , ephemeral : true,});
  
      return await interaction.reply({
        embeds:[produk],
        components: [rowproduk]
  }); 
}  
  
else if(interaction.commandName === 'pricensage'){
if(!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await interaction.reply({content : 'you dont have a permissions.' , ephemeral : true,});

return await interaction.reply({
    embeds :[nsageproduk],
    components : [rownsageproduk]
  });
  
}
  
else if(interaction.commandName === 'priceml'){
  if(!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await interaction.reply({content : 'you dont have a permissions.' , ephemeral : true,});

  return await interaction.reply({
    embeds :[mlproduk],
    components : [rowmlproduk]
  });
}

else if(interaction.commandName === 'priceff'){
      if(!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await interaction.reply({content : 'you dont have a permissions.' , ephemeral : true,});

return await  interaction.reply({
    embeds :[ffproduk],
    components :[rowffproduk]
  });
}

else if(interaction.commandName === 'priceundawn'){
  if(!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await
interaction.reply({content : 'you dont have a permissions.', ephemeral : true,});

return await interaction.reply({
  embeds : [undawnproduk],
  components : [rowundawn]
});
}  

else if(interaction.commandName === 'pricemetalslug'){
  if(!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await
interaction.reply({content : 'you dont have a permissions.', ephemeral : true,});

  return await interaction.reply({
    embeds : [mslugproduk],
    components : [rowmslugproduk]
  });
}

else if(interaction.commandName === 'pricetokenpln'){
  if(!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await 
interaction.reply({content : 'you dont have a permissions.', ephemeral : true,});

 return await interaction.reply({
   embeds : [plnproduk],
   components : [new ActionRowBuilder().addComponents(tokenpln1)]
 });
}
//Akun Game List
else if(interaction.commandName === 'akungame'){
    if(!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await interaction.reply({content : 'you dont have a permissions.' , ephemeral : true,});
  
return await  interaction.reply({
    embeds:[gameakun],
    components:[rowakungame]
  });
}  

//Contact Person List
else if (interaction.commandName === 'listcp') {
      if(!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return await interaction.reply({content : 'you dont have a permissions.' , ephemeral : true,});
  
  return await  interaction.reply({
      embeds :[contactperson],
      components:[rowsosmed],
    });
}
  





  //Give Away
else if(interaction.commandName === 'giveaway'){
if (interaction.options.getSubcommand()=== 'start'){
    const reward = interaction.options.getString('reward')
            const duration = interaction.options.getString('duration')
            const winners = interaction.options.getInteger('winners')
            const host = interaction.options.getUser('host')
            const thumbnail = interaction.options.getAttachment('thumbnail')
    
if(isNaN(ms(duration))) {return interaction.reply({ content: 'Could not parse the duration!', ephemeral: true });}

            await client.giveawaysManager.start(interaction.channel, {
                duration: ms(duration),   
                prize: reward,
                winnerCount: winners,
                hostedBy: host ? host : interaction.user,
                thumbnail: thumbnail ? thumbnail.url : null,
                messages: {
                    giveaway: "🎉 **GIVEAWAY** 🎉",
                    giveawayEnded: "🎉 **GIVEAWAY OVER** 🎉",
                    drawing: "Giveaway ends {timestamp}",
                    inviteToParticipate: "Click the 🎉 reaction below the message to participate",
                    winMessage: "🎉 Congratulations, {winners}! You won **{this.prize}** !, PM **{this.hostedBy}**"
                }
            })

            interaction.reply({content: 'Starting the giveaway...'})
  }

  if(interaction.options.getSubcommand() === 'reroll'){
            const messageID = interaction.options.getString('message-id')

            await client.giveawaysManager
                .reroll(messageID,{
                         messages: {
                            congrat: '🎉 New winner(s): {winners}! Selamat, anda memenangkan **{this.prize}**!, pm **{this.hostedBy}**'
                         }
                })
                .then(() => {
                    return interaction.reply({content: 'Picking a new winner...', ephemeral: true});
                })
                .catch((err) => {
                    return interaction.reply({content: `I\'ve ran into an error!\n\`\`${err}\`\``, ephemeral: true});
                });

            interaction.reply({content:"Rerolling giveaway...", ephemeral: true})
        }

        if(interaction.options.getSubcommand() === 'pause'){
            const messageID = interaction.options.getString('message-id')

            const giveaway = client.giveawaysManager.giveaways.find((giveaway) => giveaway.messageId === messageID && giveaway.guildId === interaction.guild.id);
            if (giveaway.pauseOptions.isPaused) return interaction.reply({content: 'This giveaway is already paused!', ephemeral: true})

            if(!giveaway) return interaction.reply({content: 'Couldn\'t parse the input message id!', ephemeral: true})

            client.giveawaysManager
                .pause(messageID)
                .then(() => {
                    return interaction.reply({content: 'Successfully paused the giveaway.', ephemeral: true});
                })
                .catch((err) => {
                    return interaction.reply({content: `I\'ve ran into an error!\n\`\`${err}\`\``, ephemeral: true});
                });


        }

        if(interaction.options.getSubcommand() === 'resume'){
            const messageID = interaction.options.getString('message-id')

            const giveaway = client.giveawaysManager.giveaways.find((giveaway) => giveaway.messageId === messageID && giveaway.guildId === interaction.guild.id);
            if (!giveaway.pauseOptions.isPaused) return interaction.reply({content: 'This giveaway is already running.', ephemeral: true})

            if(!giveaway) return interaction.reply({content: 'Couldn\'t parse the input message id!', ephemeral: true})

            client.giveawaysManager
                .unpause(messageID)
                .then(() => {
                    return interaction.reply({content: 'Successfully resumed the giveaway.', ephemeral: true});
                })
                .catch((err) => {
                    return interaction.reply({content: `An unusual error has occurred!\n\`\`${err}\`\``, ephemeral: true});
                });

        }

        if(interaction.options.getSubcommand() === 'end'){
            const messageID = interaction.options.getString('message-id')

            const giveaway = client.giveawaysManager.giveaways.find((giveaway) => giveaway.messageId === messageID && giveaway.guildId === interaction.guild.id);

            if(!giveaway) return interaction.reply({content: 'Couldn\'t parse the input message id!', ephemeral: true})

            client.giveawaysManager
                .end(messageID)
                .then(() => {
                    return interaction.reply({content: 'The giveaway has been ended.', ephemeral: true});
                })
                .catch((err) => {
                    return interaction.reply({content: `An unusual error has occurred!\n\`\`${err}\`\``, ephemeral: true});
                });

        }

        if(interaction.options.getSubcommand() === 'stop'){
            const messageID = interaction.options.getString('message-id')

            const giveaway = client.giveawaysManager.giveaways.find((giveaway) => giveaway.messageId === messageID && giveaway.guildId === interaction.guild.id);

            if(!giveaway) return interaction.reply({content: 'Couldn\'t parse the input message id!', ephemeral: true})

            client.giveawaysManager
                .delete(messageID)
                .then(() => {
                    return interaction.reply({content: 'The giveaway has been canceled.', ephemeral: true});
                })
                .catch((err) => {
                    return interaction.reply({content: `An unusual error has occurred!\n\`\`${err}\`\``, ephemeral: true});
                });
        }


}
  
// Button
else if(interaction.isButton()){
  // ML Price
  
  if(interaction.customId === 'mla'){
     await interaction.reply({
        embeds : [mla],
       ephemeral : true,
      });
  }
    
  else if (interaction.customId === 'weeklyml'){
     await interaction.reply({
        embeds : [weeklyml],
        ephemeral :true,
      });
    }
    // List Pembayaran
    else if (interaction.customId === 'bank'){
     await interaction.reply({
        embeds : [banktrans],
        ephemeral : true,
        components : [rowbank],
      });
    }
      
    else if (interaction.customId === 'ewallet'){
      await interaction.reply({
        content : '082237455940',
        ephemeral : true
      });
    }
      
    else if(interaction.customId === 'bca'){
      await interaction.reply({
        content : '0870134924' ,
        ephemeral : true
      });
    }
      
    else if(interaction.customId === 'bri'){
      await interaction.reply({
        content : '709301005619531',
        ephemeral : true
      });
    }
      
    else if(interaction.customId === 'blu'){
      await interaction.reply({
        content : '003812565347',
        ephemeral : true
      });
    }
      
    else if(interaction.customId === 'seabank'){
      await interaction.reply({
        content : '901038789954',
        ephemeral : true
      });
    }

    //Akun Owner
    else if(interaction.customId === 'ownersageakun'){
      await interaction.reply({
        embeds : [akunsagebuilder],
        components : [rowakunsage],
        ephemeral : true
      });
    }
      
    else if(interaction.customId === 'ownermlakun'){
      await interaction.reply({
        embeds : [akunmlbuilder],
        components : [new ActionRowBuilder().addComponents(cekml)],
        ephemeral : true
      });
    }

     else if(interaction.customId === 'ownermetalslugakun'){
      await interaction.reply({
        embeds : [akunmetalslugbuilder],
        ephemeral : true
      });
    }

//Product List
    else if(interaction.customId === 'topupjoki'){
      await interaction.reply({
        embeds : [embedjoki],
        ephemeral : true
      });
    }
      
   else if(interaction.customId === 'topuppc'){
      await interaction.reply({
        embeds : [embedtopuppc],
        ephemeral : true
      });
    }
     
   else if(interaction.customId === 'topupdaily'){
      await interaction.reply({
        embeds : [embedtopupdaily],
        ephemeral : true
      });
    }
     
  else if(interaction.customId === 'topupmobile'){
      await interaction.reply({
        embeds : [embedtopupmobile],
        ephemeral : true
      });
    }  

    // Produk Ninja Sage
  else if(interaction.customId === 'sagejoki1'){
      await interaction.reply({
        embeds : [jokisage1],
        ephemeral : true
      });
    }
    
  else if(interaction.customId === 'sagejoki2'){
      await interaction.reply({
        embeds : [jokisage2],
        ephemeral : true
      });
    }
    
  else if(interaction.customId === 'sagejoki3'){
      await interaction.reply({
        embeds : [jokisage3],
        ephemeral : true});
    }

    //Produk Free Fire
else if (interaction.customId === 'ff1'){
      await interaction.reply({
        embeds : [dmff],
        ephemeral : true
  });
}
  
    else if (interaction.customId === 'ff2'){
      await interaction.reply({
        embeds : [ffpass],
        ephemeral : true
  });
}
      
    else if (interaction.customId === 'ff3'){
      await interaction.reply({
        embeds : [ffbpcard], 
        ephemeral : true
  });
}

      // List Akun Ninja Sage
else if (interaction.customId === 'sageakun1'){
  await interaction.reply({
    content : '66754 (Warga#990)\n92060 (Zabuzaz)',
    ephemeral : true
  });
}      

else if (interaction.customId === 'sageakun2'){
  await interaction.reply({
    content : 'Belom levelling :V',
    ephemeral : true,
  });
}
      
 else if (interaction.customId === 'sageakun3'){
   await interaction.reply({
      content : '8510 (Pak RT)\n24503 (Pak RW)',
     ephemeral : true,
   });
 }      

 else if (interaction.customId === 'sageakun4'){
    await interaction.reply({
      content : '1108 (Pak Presiden)\n32399 (Pak Lurah)',
      ephemeral : true,
    });
 }

   //List Akun ML
  else if (interaction.customId === 'cekml'){
    await interaction.reply({
      content : '972895209',
      ephemeral : true,
    });
 }

  // Produk Undawn
  else if (interaction.customId === 'undawntu1'){
    await interaction.reply({
      embeds : [undawntopup1],
      ephemeral : true,
    });
 }
  
  else if (interaction.customId === 'undawntu2'){
    await interaction.reply({
     embeds : [undawntopup2],
      ephemeral : true,
    });
 }

  else if (interaction.customId === 'undawntu3'){
    await interaction.reply({
      embeds : [undawntopup3],
      ephemeral : true,
    });
 }
    
  else if (interaction.customId === 'undawntu4'){
    await interaction.reply({
      embeds : [undawntopup4],
      ephemeral : true,
    });
                  }
    
// Produk Metal Slug
  else if (interaction.customId === 'msl1'){
    await interaction.reply({
      embeds : [mslug1],
      ephemeral : true,
    });
 }

  else if (interaction.customId === 'msl2'){
    await interaction.reply({
      embeds : [mslug2],
      ephemeral : true,
    });
 }
    
  else if(interaction.customId === 'tokenpln1'){
    await interaction.reply({
      embeds : [tokenpln],
      ephemeral : true,
    });
  }
  
} 
  
});

async function main() {
  const commands = [
    OrderCommand,
    setrolesCommand,
    rerolesCommand,
    reactionrolesCommand,
    UsersCommand,
    ChannelsCommand,
    BanCommand,
    RegisterCommand,
    haloCommand,
    pricemlCommand,
    paymentListCommand,
    contactpersonCommand,
    akungameCommand,
    produkCommand,
    pricensageCommand,
    priceffCommand,
    priceundawnCommand,
    giveawayCommand,
    pricemetalslugCommand,
    pricetokenplnCommand,
    
  ];
  try {
    console.log('Started refreshing application (/) commands.');
    await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), {
      body: commands,
    });

    client.login(TOKEN);
  } catch (err) {
    console.log(err);
  }
}

main();