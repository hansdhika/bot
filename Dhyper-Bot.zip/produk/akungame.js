import { EmbedBuilder } from '@discordjs/builders';

export const akunsagelevel1 = new EmbedBuilder().setTitle('List Harga Free Fire').setDescription('**List Akun Level 20**\n\n\n').setThumbnail('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTHaeHqUD-3jJ_HA8BgaHhzATypBB6u0vURGg&usqp=CAU').setTimestamp().setFooter({text:'Updated'});