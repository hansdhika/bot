import {EmbedBuilder} from 'discord.js';

export const pubgmproduk = new EmbedBuilder().setTitle('List Harga PUBGM').setDescription('Tekan tombol dibawah ini untuk melihat harga\n\n\nBack to <#1143958165407404203>').setThumbnail('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT91LHBQ-xFpUPmUX9tDzdG8MKuvDKbAGHS7g&usqp=CAU').setTimestamp().setFooter({text:'Updated'});